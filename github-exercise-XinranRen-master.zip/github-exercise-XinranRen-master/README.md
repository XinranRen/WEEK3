# Guideline for Exercise - Week Two 
